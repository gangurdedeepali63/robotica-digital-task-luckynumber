
<!DOCTYPE>
<html>
<head>
	<title>PHP Assignment</title>
</head>
<body>
<form method="POST" action="" class="row g-3">
	<div class="container">
		<div class="row">
			<div class="col-12">
		        <label for="Number" class="form-label">Enter Number</label>
		            
		                <input type="number" name="in_number" class="form-control" id="in_number" min="1" step="1" required>
		                 <input type="submit" value="Submit" name="submit">
		            
		    </div>
		</div>
	</div>
</form>


<script type="text/JavaScript">
        
        document.getElementById("in_number").addEventListener("input", function() {
           this.value = this.value.replace(/[^0-9]/g, '');
        });
</script>

<?php


if(isset($_POST['submit'])){
		$input_number = $_POST['in_number'];
		if($input_number){
			$result = findLuckyNumber($input_number);
			echo 'The output after skipping the entered number is: '. $result;
		}
}

function findLuckyNumber($input_number) {
    $cnt = 0; 
    $num = 0; 
    while ($cnt < $input_number) {
        $num++; 
        if (strpos((string)$num, '3') === false) {
            $cnt++;
        }
    }
    return $num;
}


?>

</body>
</html>

